#include "Binh.h"
boolean ESPHB::wifi_Init(char * STAssid,char * STApassword,char * APssid,char * APpassword){
	unsigned char timeout=0;
	boolean _ap=false;
	WiFi.mode(WIFI_STA);
	Serial.print("Connecting to ");
	Serial.println(STAssid);
	Serial.println(STApassword);
	WiFi.begin(STAssid, STApassword);    // Connect to wifi
	while (WiFi.status() != WL_CONNECTED) {
		delay(500); 
		Serial.print(".");
		timeout++;
		if(timeout>60){
			_ap=true;
			WiFi.mode(WIFI_AP_STA);
			WiFi.softAP(APssid, APpassword);
			Serial.println("Cannot connected, you can connect to:");
			Serial.println(WiFi.softAPIP());
			break;
		}
	}
	if(!_ap){
		Serial.println("WiFi connected to:");
		Serial.println(STAssid);
		Serial.println(WiFi.localIP());  // Print the IP
    }
	return !_ap;
};

void ESPHB::start_EEPROM(int size){	// Init EEPROM with size (bytes)
	EEPROM.begin(size);
}

void ESPHB::read_configs(configs *cf,String stSerial,String stKey){
	// read fist startup to config serial and first key connect to EEPROM
	// 9 is not fist startup
	char ststart = read1byte_EEPROM(__first_start);
	cf->st_start = ststart;
	if (ststart != 9) { // write serial
		update_EEPROM(__serial_adrr, __serial_max, stSerial);
		update_EEPROM(__key_adrr, __key_max, stKey);
		Serial.println("\nUpdated: serial - " + stSerial + "key: " + stKey);
		update1byte_EEPROM(__first_start, 9);
	}
	char *a = read_EEPROM(__serial_adrr);  cf->serial = a;  free(a);  // Read serial of device
	char *b = read_EEPROM(__key_adrr);  cf->key = b;  free(b);  // Read key to connect to device
	char *c = read_EEPROM(__ssid_adrr);  cf->ssid = c;  free(c);  // Read ssid of wifi
	char *d = read_EEPROM(__password_adrr);  cf->password = d;  free(d);  // Read password of wifi
	char *e = read_EEPROM(__IP_adrr);  cf->ip = e;  free(e);  // Read IP of device
};

boolean ESPHB::save_configs(unsigned char content,String value){
	unsigned char address,maxlegth=0;
	switch(content){
		case __key:{	address=__key_adrr;	maxlegth=__key_max;}	break;
		case __ssid:{	address=__ssid_adrr;	maxlegth=__ssid_max;}	break;
		case __password:{	address=__password_adrr;	maxlegth=__password_max;}	break;
		case __IP:{	address=__IP_adrr;	maxlegth=__IP_max;}	break;
	};
	if(maxlegth)	{
		update_EEPROM(address, maxlegth, value);
		return true;
	}
	else return false;
};

void ESPHB::toggle_pin(String pinname, String value){	// toggle pinout
  digitalWrite(get_pin(pinname), pin_value(value));
}

void ESPHB::getDecode(request *s, String http_rq){
	// get GET the request
	// indexOf(string, start poistion) returns the position (i.e. index) of a particular character
	// GET /?c=setup&&ssid=trungthanh&&pass=12112007 HTTP/1.1\r\nHost: 192.168.4.1\r\nConnection: close\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,
	unsigned char index=0;
	http_read rq[10];  // Init configs struct
	int start = http_rq.indexOf('/');
    int compare = 0;
    int ends = http_rq.indexOf(' ', start);
    while(start>0){
      compare = http_rq.indexOf('=', start);
      rq[index].names=http_rq.substring(start+2, compare);
      start = http_rq.indexOf('&', compare);
      if(start<0){
        rq[index].value=http_rq.substring(compare+1, ends);
      }else{ rq[index].value=http_rq.substring(compare+1, start);}
      index++;
    };
    // process request to _get
    for(unsigned char i=0;i<=index;i++){
      if(rq[i].names=="command"){s->command=rq[i].value;}	// -> and not . because *s: pointer
        else if(rq[i].names=="key"){s->key=rq[i].value;}
        else if(rq[i].names=="newkey"){s->newkey=rq[i].value;}
        else if(rq[i].names=="ssid"){s->ssid=rq[i].value;}
        else if(rq[i].names=="password"){s->password=rq[i].value;}
        else if(rq[i].names=="ip"){s->ip=rq[i].value;}
        else if(rq[i].names=="pin"){s->pin=rq[i].value;}
        else if(rq[i].names=="value"){s->value=rq[i].value;}
    };
};

void ESPHB::jsonEncode(int pos, String * s, String key, String val){
	switch (pos) {
        case ONEJSON:
        case FIRSTJSON:
            *s += "{\r\n";
            jsonAdd(s,key,val);
            *s+= (pos==ONEJSON) ? "\r\n}" : ",\r\n";
            break;
        case NEXTJSON:
            jsonAdd(s,key,val);
            *s+= ",\r\n";
            break;
        case LASTJSON:
            jsonAdd(s,key,val);
            *s+= "\r\n}";
            break;
    };
}

unsigned char ESPHB::read1byte_EEPROM(unsigned char addr) {	
  return EEPROM.read(addr);  // return 1 byte of result
}

char* ESPHB::read_EEPROM(unsigned char addr) {
  unsigned char len = EEPROM.read(addr);  // Read leghth of array in fisrt byte of block content in EEPROM
  char *re;
  re = (char*)malloc(len);
  for (unsigned char i = 0; i < len; i++) {
    re[i] = EEPROM.read(i + addr + 1);  // Read byte to byte, start from second byte of block content in EEPROM
  }
  return re;  // return array of result
}
void ESPHB::update1byte_EEPROM(unsigned char addr, unsigned char value){
    EEPROM.write(addr, value);  // Write 1 byte to EEPROM at addr
    EEPROM.commit();// Save from RAM to EEPROM
}

boolean ESPHB::update_EEPROM(unsigned char addr, unsigned char maxlen, String text){
  char len = text.length() + 1;  // leghth of array (=leghth of string +1) will be write to EEPROM; +1 because: end of array is "\0"
  char arr[len];  // Init an array
  text.toCharArray(arr, len);  // Convert string to array
  if (len <= maxlen) {  // Write array to EEPROM when leghth of array <= max leghth in EEPROM
    EEPROM.write(addr, len);  // Write leghth of array in fisrt byte of block content in EEPROM
    for (unsigned char i = 0; i < len; i++) {
      EEPROM.write(i + addr + 1, arr[i]);  // Write byte by byte, start from second byte of block content in EEPROM
    }
    EEPROM.commit();// Save from RAM to EEPROM
    return true;  // Return true when leghth of array <= max leghth in EEPROM
  } else {
    return false;  // Return false when leghth of array > max leghth in EEPROM and not save to EEPROM
  }
}

unsigned char ESPHB::get_pin(String pin){	// Get pin name from string to int
	return pin.substring(3,pin.length()).toInt();
}
boolean ESPHB::pin_value(String value){	// Get pin value from string to boolean
	if(value=="ON"){return HIGH;}else if(value=="OFF"){return LOW;};
}

void ESPHB::jsonAdd(String *s, String key,String val) {
    *s += '"' + key + '"' + ":" + '"' + val + '"';
}


