#ifndef Binh_h
#define Binh_h

#include <ESP8266WiFi.h>
#include <WiFiClient.h> 
#include <ESP8266WebServer.h>
#include <EEPROM.h>

// EEPROM byte:
// 0: bien khoi dong - 0: khoi dong lan dau; 1: khoi dong lan sau
// x0: so ky tu trong chuoi
// 10-19: num byte of SERIAL  (max 9)
// 20-29: num byte of key  (max 9)
// 30-69: num byte of ssid  (max 39)
// 70-109: num byte of password (max 39)
// arrtostr: String var; ga'n: var=arr

#define __first_start 0
#define __serial_adrr 10
#define __serial_max 9
#define __key	1
#define __key_adrr 20
#define __key_max 9
#define __ssid	2
#define __ssid_adrr 30
#define __ssid_max 39
#define __password	3
#define __password_adrr 70
#define __password_max 39
#define __IP	4
#define __IP_adrr 110
#define __IP_max 4

// Json encode
#define	ONEJSON	1
#define	FIRSTJSON	2
#define	NEXTJSON	3
#define	LASTJSON	4

struct configs {
  unsigned char st_start;
  String serial;
  String key;
  String ssid;
  String password;
  String ip;
};
struct http_read {
  String names;
  String value;
};
struct request{
  String command;
  String key;
  String newkey;
  String ssid;
  String password;
  String ip;
  String pin;
  String value;
};
class ESPHB
{
	public:
		boolean wifi_Init(char * STAssid,char * STApassword,char * APssid,char * APpassword);
		void start_EEPROM(int size);
		void read_configs(configs *cf,String stSerial,String stKey);
		boolean save_configs(unsigned char content,String value);
		void toggle_pin(String pinname, String value);
		void getDecode(request *s, String http_rq);
		void jsonEncode(int pos, String * s, String key, String val);
	private:
		unsigned char read1byte_EEPROM(unsigned char addr);
		char *read_EEPROM(unsigned char addr);
		void update1byte_EEPROM(unsigned char addr, unsigned char value);
		boolean update_EEPROM(unsigned char addr, unsigned char maxlen, String text);
		unsigned char get_pin(String pin);
		boolean pin_value(String value);
		void jsonAdd(String *s, String key,String val);
};
#endif